-- AlterTable
ALTER TABLE "Availability" ADD COLUMN     "date" TEXT;
